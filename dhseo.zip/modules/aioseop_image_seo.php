<?php
/**
 * Loads the Image SEO class file.
 *
 * @since   3.4.0
 * @package DH-SEO-Pack
 */

if ( DHSEOPRO ) {
	require_once( DHSEO_PLUGIN_DIR . 'pro/class-aioseop-image-seo.php' );
}
