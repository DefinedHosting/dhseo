<?php
/**
 * Loads the Local Business schema class.
 * 
 * @since 3.6.0
 */

if ( DHSEOPRO ) {
	require_once( DHSEO_PLUGIN_DIR . 'pro/modules/class-aioseop-schema-local-business.php' );
}
